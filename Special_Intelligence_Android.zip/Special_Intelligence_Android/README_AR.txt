# Special Intelligence — Android project

هذا مشروع Android يحتوي على تطبيق Special Intelligence داخل WebView محلي.

## بناء APK باستخدام Android Studio
1. ثبّت Android Studio على جهاز كمبيوتر.
2. فك ضغط ملف `Special_Intelligence_Android.zip`.
3. افتح مجلد `Special_Intelligence_Android` من Android Studio.
4. انتظر اكتمال Gradle Sync وثبّت Android SDK Platform 35 إذا طُلب منك.
5. من القائمة اختر: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. بعد نجاح البناء ستجد الملف عادة في:
   `app/build/outputs/apk/debug/app-debug.apk`

## ملاحظات
- وظائف التشفير وفك التشفير تعمل محلياً، ولا تتطلب خادماً.
- مشاركة واتساب تتطلب اتصالاً بالإنترنت وتوفر واتساب أو متصفح مناسب.
- التطبيق لا يرسل النصوص إلى خادم.
- لا تنس الاحتفاظ بمفتاح AES؛ لا يمكن استعادة الرسائل المحمية من دونه.
